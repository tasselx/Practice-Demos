# 效果图

![BottomNavigation](https://raw.githubusercontent.com/ansen666/BottomNavigation/master/image/result.gif)
